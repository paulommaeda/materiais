<?php
namespace K8Produtos;
defined('ABSPATH') || exit;

final class Views
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'menu']);
        add_shortcode('k8_produto', [self::class, 'product_shortcode']);
        add_shortcode('k8_dashboard', [self::class, 'dashboard_shortcode']);
        // As páginas antigas continuam funcionando após a migração.
        add_shortcode('pagamento_material_didatico', static function ($atts) {
            $atts = is_array($atts) ? $atts : [];
            $atts['id'] = $atts['produto'] ?? get_option('k8prod_legacy_product_id', 0);
            return self::product_shortcode($atts);
        });
        foreach (['dashboard_material_didatico' => 'overview', 'entrega_material_didatico' => 'deliveries', 'k8pm_dashboard' => 'stock'] as $tag => $tab) {
            add_shortcode($tag, static function ($atts) use ($tab) {
                return self::dashboard_shortcode(array_merge(is_array($atts) ? $atts : [], ['aba' => $tab]));
            });
        }
    }

    public static function menu(): void
    {
        add_menu_page('K8 Produtos', 'K8 Produtos', 'k8_manage_products', 'k8prod', [self::class, 'admin_dashboard'], 'dashicons-products', 31);
        add_submenu_page('k8prod', 'Dashboard', 'Dashboard', 'k8_manage_products', 'k8prod', [self::class, 'admin_dashboard']);
        add_submenu_page('k8prod', 'Produtos e preços', 'Produtos e preços', 'manage_options', 'k8prod-products', [self::class, 'admin_products']);
        add_submenu_page('k8prod', 'Configurações K8', 'Configurações', 'manage_options', 'k8prod-settings', [self::class, 'admin_settings']);
    }

    private static function assets(): void
    {
        wp_enqueue_style('k8prod', plugins_url('assets/app.css', K8PROD_FILE), [], K8PROD_VERSION);
        wp_enqueue_script('k8prod', plugins_url('assets/app.js', K8PROD_FILE), [], K8PROD_VERSION, true);
    }

    private static function shell(string $extra = ''): void
    {
        self::assets();
        echo '<div class="k8prod ' . esc_attr($extra) . '" data-ajax="' . esc_url(admin_url('admin-ajax.php')) . '" data-nonce="' . esc_attr(wp_create_nonce('k8prod_manage')) . '"><div class="k8-notice" role="status" aria-live="polite" hidden></div>';
    }

    private static function form(string $op, int $product, string $class = '', string $confirmation = ''): void
    {
        echo '<form class="k8-form ' . esc_attr($class) . '" data-k8-manage="' . esc_attr($op) . '"' . ($confirmation ? ' data-k8-confirm="' . esc_attr($confirmation) . '"' : '') . '><input type="hidden" name="produto_id" value="' . (int) $product . '">';
    }

    private static function field(string $name, string $label, $value = '', string $type = 'text', string $extra = ''): void
    {
        echo '<label>' . esc_html($label) . '<input name="' . esc_attr($name) . '" type="' . esc_attr($type) . '" value="' . esc_attr((string) $value) . '" ' . $extra . '></label>';
    }

    private static function button(string $label): void
    {
        echo '<button class="k8-btn" type="submit">' . esc_html($label) . '</button>';
    }

    private static function currency($value): string
    {
        return 'R$ ' . number_format((float) $value, 2, ',', '.');
    }

    public static function product_shortcode($atts): string
    {
        $atts = shortcode_atts(['id' => 0, 'produto' => 0], $atts, 'k8_produto');
        try {
            $product = Support::product(absint($atts['id'] ?: $atts['produto']), true);
        } catch (\Throwable $e) {
            return '';
        }
        self::assets();
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        ob_start();
        ?>
        <section class="k8prod k8-public" data-k8-product="<?php echo (int) $product->id; ?>" data-stages="<?php echo (int) $product->etapas; ?>" data-ajax="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" hidden>
            <div class="k8-eyebrow">Compra e acompanhamento</div>
            <h2><?php echo esc_html($product->nome); ?></h2>
            <?php if ($product->descricao): ?><p class="k8-muted"><?php echo nl2br(esc_html($product->descricao)); ?></p><?php endif; ?>
            <ol class="k8-steps"><li>Identificação</li><li>Aluno e pagamento</li><li>Acompanhamento</li></ol>
            <div class="k8-notice" role="status" aria-live="polite" hidden></div>
            <form class="k8-form" data-k8-lookup>
                <label>CPF do responsável<input name="cpf" inputmode="numeric" autocomplete="off" maxlength="14" placeholder="000.000.000-00" required></label>
                <button class="k8-btn" type="submit">Consultar alunos</button>
            </form>
            <div data-k8-students></div>
            <div data-k8-checkout hidden>
                <div data-k8-summary></div>
                <form class="k8-form k8-inline" data-k8-coupon><label>Cupom de desconto<input name="cupom" maxlength="50" autocomplete="off" placeholder="Opcional"></label><button type="submit" class="k8-btn secondary">Aplicar cupom</button></form>
                <fieldset class="k8-form k8-email-contact" data-k8-email hidden>
                    <legend>E-mail da compra</legend>
                    <label>Seu e-mail<input name="email_responsavel" type="email" autocomplete="email" maxlength="254" data-k8-email-input></label>
                    <p class="k8-muted" data-k8-email-info></p>
                    <label class="k8-check" data-k8-reminder-label hidden><input type="checkbox" name="lembrete_email" value="1" data-k8-reminder>Quero receber um lembrete por e-mail se não concluir esta compra.</label>
                    <p class="k8-muted" data-k8-email-state role="status" aria-live="polite"></p>
                </fieldset>
                <p class="k8-price" data-k8-price></p>
                <p class="k8-muted" data-k8-payment-terms hidden></p>
                <fieldset class="k8-form k8-form-grid" data-k8-pay-address hidden disabled>
                    <legend>Endereço para o boleto</legend>
                    <p class="k8-muted">O banco exige o endereço do pagador para emitir o boleto. Preencha e clique novamente em Boleto para continuar.</p>
                    <label>CEP<input name="pay_cep" data-k8-address-field inputmode="numeric" autocomplete="postal-code" maxlength="9" pattern="[0-9]{5}-?[0-9]{3}" required></label>
                    <label>Endereço<input name="pay_endereco" data-k8-address-field autocomplete="address-line1" maxlength="255" required></label>
                    <label>Número (somente dígitos)<input name="pay_numero" data-k8-address-field inputmode="numeric" pattern="[0-9]{1,20}" maxlength="20" required></label>
                    <label>Complemento<input name="pay_complemento" data-k8-address-field autocomplete="address-line2" maxlength="255"></label>
                    <label>Bairro<input name="pay_bairro" data-k8-address-field maxlength="100" required></label>
                    <label>Cidade<input name="pay_cidade" data-k8-address-field autocomplete="address-level2" maxlength="100" required></label>
                    <label>UF<select name="pay_uf" data-k8-address-field autocomplete="address-level1" required><option value="">Selecione</option><?php foreach (['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'] as $state) echo '<option value="' . $state . '">' . $state . '</option>'; ?></select></label>
                </fieldset>
                <div class="k8-methods"><button class="k8-btn" data-method="Pix" type="button" hidden>Pagar com Pix</button><button class="k8-btn secondary" data-method="Boleto" type="button" hidden>Boleto</button><button class="k8-btn secondary" data-method="Cartao" type="button" hidden>Cartão de crédito</button></div>
                <button class="k8-btn" data-method="Cortesia" type="button" hidden>Finalizar sem custo</button>
            </div>
            <div data-k8-status aria-live="polite"></div>
        </section>
        <?php
        return ob_get_clean();
    }

    public static function admin_dashboard(): void
    {
        echo self::dashboard_shortcode([]);
    }

    public static function dashboard_shortcode($atts): string
    {
        if (!current_user_can('manage_options') && !current_user_can('k8_manage_products')) {
            return '<p>Entre com uma conta autorizada para administrar os produtos.</p>';
        }
        $atts = shortcode_atts(['produto' => 0, 'aba' => 'overview'], $atts, 'k8_dashboard');
        $products = Support::products();
        $id = absint($_GET['k8_product'] ?? $atts['produto']);
        if (!$id && $products) {
            $id = (int) $products[0]->id;
        }
        if ($id && !Support::can_manage($id)) {
            return '<p>Sem permissão para este produto.</p>';
        }
        ob_start();
        self::shell('k8-dashboard');
        echo '<div class="k8-heading"><div><div class="k8-eyebrow">K8 Produtos</div><h1>Administração por produto</h1></div></div>';
        if (!$products) {
            echo '<div class="k8-card"><p>Cadastre o primeiro produto para começar.</p>';
            if (current_user_can('manage_options')) {
                echo '<a class="k8-btn" href="' . esc_url(admin_url('admin.php?page=k8prod-products')) . '">Criar produto</a>';
            }
            echo '</div></div>';
            return ob_get_clean();
        }
        try {
            $product = Support::product($id);
            $tabs = ['overview' => 'Visão geral', 'orders' => 'Pedidos', 'stock' => 'Estoque', 'deliveries' => 'Entregas', 'coupons' => 'Cupons', 'history' => 'Histórico'];
            $tab = sanitize_key($_GET['k8_tab'] ?? $atts['aba']);
            if (!isset($tabs[$tab])) {
                $tab = 'overview';
            }
            echo '<form method="get" class="k8-filters">';
            if (is_admin()) {
                echo '<input type="hidden" name="page" value="k8prod">';
            }
            echo '<input type="hidden" name="k8_tab" value="' . esc_attr($tab) . '"><label>Produto<select name="k8_product">';
            foreach ($products as $p) {
                echo '<option value="' . (int) $p->id . '" ' . selected($id, $p->id, false) . '>' . esc_html($p->nome . ($p->ativo ? '' : ' (inativo)')) . '</option>';
            }
            echo '</select></label><button type="submit" class="k8-btn secondary">Selecionar produto</button></form>';
            echo '<nav class="k8-tabs" aria-label="Seções do produto">';
            foreach ($tabs as $key => $label) {
                $url = add_query_arg(['k8_product' => $id, 'k8_tab' => $key, 'k8_page' => 1]);
                echo '<a ' . ($key === $tab ? 'aria-current="page"' : '') . ' href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
            }
            echo '</nav><div class="k8-product-title"><h2>' . esc_html($product->nome) . '</h2><code>[k8_produto id="' . $id . '"]</code></div>';
            if (current_user_can('manage_options')) {
                echo '<p><a href="' . esc_url(admin_url('admin.php?page=k8prod-products&produto_id=' . $id)) . '">Editar turmas e preços deste produto</a></p>';
            }
            if ($tab === 'overview') {
                self::overview($product);
            } elseif ($tab === 'orders') {
                self::orders($product);
            } elseif ($tab === 'stock') {
                self::stock($product);
            } elseif ($tab === 'deliveries') {
                self::deliveries($product);
            } elseif ($tab === 'coupons') {
                self::coupons($product);
            } else {
                self::history($product);
            }
        } catch (\Throwable $e) {
            echo '<p class="k8-error">' . esc_html($e->getMessage()) . '</p>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private static function overview(object $p): void
    {
        global $wpdb;
        $orders = Support::table('pedidos');
        $deliveries = Support::table('entregas');
        $materials = Support::table('materiais');
        $counts = $wpdb->get_row($wpdb->prepare("SELECT COUNT(*) AS pedidos, COUNT(DISTINCT CASE WHEN status_pagamento = 'Paga' THEN ra END) AS pagos,
            COALESCE(SUM(CASE WHEN status_pagamento = 'Paga' THEN valor ELSE 0 END),0) AS recebido,
            SUM(CASE WHEN status IN ('gerado','iniciado','verificacao') AND (status_pagamento IS NULL OR status_pagamento NOT IN ('Paga','Cancelada')) THEN 1 ELSE 0 END) AS pendentes
            FROM $orders WHERE produto_id = %d", $p->id));
        $delivered = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $deliveries WHERE produto_id = %d AND status = 'entregue'", $p->id));
        $low = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $materials WHERE produto_id = %d AND ativo = 1 AND estoque_atual <= estoque_minimo", $p->id));
        echo '<div class="k8-metrics">';
        foreach (['Alunos com pagamento confirmado' => (int) $counts->pagos, 'Valor confirmado' => self::currency($counts->recebido),
            'Pedidos aguardando pagamento' => (int) $counts->pendentes, 'Entregas realizadas' => $delivered, 'Materiais para reposição' => $low] as $label => $value) {
            echo '<div class="k8-card"><span class="k8-muted">' . esc_html($label) . '</span><strong class="k8-number">' . esc_html((string) $value) . '</strong></div>';
        }
        echo '</div>';
        $paid = array_fill_keys($wpdb->get_col($wpdb->prepare("SELECT DISTINCT ra FROM $orders WHERE produto_id = %d AND status_pagamento = 'Paga'", $p->id)), true);
        $summary = [];
        $pending = [];
        try {
            foreach (Students::all() as $student) {
                if ((!ProductClasses::allows($p, $student->turma) || $p->valor_padrao === null) && !isset($paid[$student->ra])) {
                    continue;
                }
                if (!isset($summary[$student->turma])) {
                    $summary[$student->turma] = ['total' => 0, 'paid' => 0];
                }
                $summary[$student->turma]['total']++;
                if (isset($paid[$student->ra])) {
                    $summary[$student->turma]['paid']++;
                } else {
                    $pending[] = $student;
                }
            }
        } catch (\Throwable $e) {
            echo '<p class="k8-muted">' . esc_html($e->getMessage()) . '</p>';
        }
        echo '<div class="k8-grid"><section class="k8-card"><h3>Adesão por turma</h3>';
        foreach ($summary as $class => $row) {
            $percent = $row['total'] ? round(100 * $row['paid'] / $row['total']) : 0;
            echo '<p>' . esc_html($class) . ' <span class="k8-muted">' . (int) $row['paid'] . ' / ' . (int) $row['total'] . '</span></p><progress value="' . $percent . '" max="100">' . $percent . '%</progress>';
        }
        if (!$summary) {
            echo '<p>Aguardando a configuração da base e dos preços por turma.</p>';
        }
        echo '</section><section class="k8-card"><h3>Pagamentos por método</h3>';
        $methods = $wpdb->get_results($wpdb->prepare("SELECT metodo,COUNT(*) AS total,SUM(valor) AS valor FROM $orders WHERE produto_id = %d AND status_pagamento = 'Paga' GROUP BY metodo ORDER BY total DESC", $p->id));
        foreach ($methods as $m) {
            echo '<p><strong>' . esc_html($m->metodo) . '</strong> · ' . (int) $m->total . ' pedido(s) · ' . esc_html(self::currency($m->valor)) . '</p>';
        }
        echo '</section></div><details class="k8-card"><summary>Alunos sem pagamento confirmado (' . count($pending) . ')</summary><p class="k8-muted">Situação atual dos alunos elegíveis ao produto. Exibição de até 200 registros.</p>';
        self::table_start(['Aluno', 'RA', 'Turma']);
        foreach (array_slice($pending, 0, 200) as $student) {
            echo '<tr><td>' . esc_html($student->nome_aluno) . '</td><td>' . esc_html($student->ra) . '</td><td>' . esc_html($student->turma) . '</td></tr>';
        }
        self::table_end();
        echo '</details>';
    }

    private static function filters(int $product, string $tab, bool $delivery = false): array
    {
        $class = sanitize_text_field(wp_unslash($_GET['k8_class'] ?? ''));
        $search = sanitize_text_field(wp_unslash($_GET['k8_search'] ?? ''));
        $state = sanitize_key($_GET['k8_state'] ?? '');
        $from = sanitize_text_field($_GET['k8_from'] ?? '');
        $to = sanitize_text_field($_GET['k8_to'] ?? '');
        foreach (['from', 'to'] as $key) {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $$key)) {
                $$key = '';
            }
        }
        echo '<form method="get" class="k8-filters">';
        if (is_admin()) {
            echo '<input type="hidden" name="page" value="k8prod">';
        }
        echo '<input type="hidden" name="k8_product" value="' . $product . '"><input type="hidden" name="k8_tab" value="' . esc_attr($tab) . '">';
        self::field('k8_class', 'Turma', $class);
        self::field('k8_search', 'Aluno ou RA', $search);
        if (!$delivery) {
            self::field('k8_from', 'Pedido a partir de', $from, 'date');
            self::field('k8_to', 'Pedido até', $to, 'date');
        } else {
            echo '<input type="hidden" name="k8_stage" value="' . max(1, min(2, absint($_GET['k8_stage'] ?? 1))) . '">';
            echo '<label>Situação<select name="k8_state"><option value="">Todas</option><option value="pendente" ' . selected($state, 'pendente', false) . '>Pendente</option><option value="entregue" ' . selected($state, 'entregue', false) . '>Entregue</option></select></label>';
        }
        self::button('Filtrar');
        echo '</form>';
        return compact('class', 'search', 'state', 'from', 'to');
    }

    private static function where(int $product, array $filter): string
    {
        global $wpdb;
        $where = $wpdb->prepare('p.produto_id = %d', $product);
        if ($filter['class']) {
            $where .= $wpdb->prepare(' AND p.turma = %s', $filter['class']);
        }
        if ($filter['search']) {
            $like = '%' . $wpdb->esc_like($filter['search']) . '%';
            $where .= $wpdb->prepare(' AND (p.ra LIKE %s OR p.nome_aluno LIKE %s)', $like, $like);
        }
        if ($filter['from']) {
            $where .= $wpdb->prepare(' AND p.criado_em >= %s', $filter['from'] . ' 00:00:00');
        }
        if ($filter['to']) {
            $where .= $wpdb->prepare(' AND p.criado_em <= %s', $filter['to'] . ' 23:59:59');
        }
        return $where;
    }

    private static function table_start(array $headers): void
    {
        echo '<div class="k8-scroll"><table><thead><tr>';
        foreach ($headers as $header) {
            echo '<th>' . esc_html($header) . '</th>';
        }
        echo '</tr></thead><tbody>';
    }

    private static function table_end(): void
    {
        echo '</tbody></table></div>';
    }

    private static function pagination(int $total, int $page): void
    {
        echo '<div class="k8-pagination"><span>' . $total . ' registro(s) · página ' . $page . '</span>';
        if ($page > 1) {
            echo '<a href="' . esc_url(add_query_arg('k8_page', $page - 1)) . '">Anterior</a>';
        }
        if ($page * 50 < $total) {
            echo '<a href="' . esc_url(add_query_arg('k8_page', $page + 1)) . '">Próxima</a>';
        }
        echo '</div>';
    }

    private static function orders(object $p): void
    {
        global $wpdb;
        $filter = self::filters((int) $p->id, 'orders');
        self::form('sync', (int) $p->id, 'k8-inline');
        self::button('Consultar pagamentos agora');
        echo '<span class="k8-muted">Até 30 por vez; consulta automática a cada cinco minutos pelo WP-Cron.</span></form>';
        $where = self::where((int) $p->id, $filter);
        $table = Support::table('pedidos');
        $page = max(1, absint($_GET['k8_page'] ?? 1));
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table p WHERE $where");
        $rows = $wpdb->get_results($wpdb->prepare("SELECT p.* FROM $table p WHERE $where ORDER BY p.id DESC LIMIT 50 OFFSET %d", ($page - 1) * 50));
        self::table_start(['Pedido', 'Aluno', 'Responsável', 'Pagamento', 'Ações']);
        foreach ($rows as $o) {
            echo '<tr><td>#' . (int) $o->id . '<br><small>' . esc_html($o->criado_em) . '</small></td><td><strong>' . esc_html($o->nome_aluno) . '</strong><br>RA ' . esc_html($o->ra) . ' · ' . esc_html($o->turma) . '</td><td>' . esc_html($o->nome_resp) . '</td><td>' . esc_html(self::currency($o->valor)) . '<br>' . esc_html($o->metodo) . '<br><small>' . (PayPayments::is_pay($o) ? 'PAY — ' . esc_html($o->pagamento_ambiente === 'production' ? 'produção' : 'teste') : 'COB / legado') . '</small><br><span class="k8-badge">' . esc_html($o->status_pagamento ?: $o->status) . '</span></td><td>';
            if ($o->cartao_parcelas_max) echo '<p class="k8-muted">Cartão: até ' . (int) $o->cartao_parcelas_max . ' parcela(s).</p>';
            if (PayPayments::is_pay($o) && !$o->erro_mensagem) echo '<p class="k8-muted">Referência PAY: ' . esc_html(PayPayments::reference($o)) . '</p>';
            if (PayPayments::is_pay($o) && $o->pay_checkout_id) echo '<p class="k8-muted">ID do checkout PAY: ' . esc_html($o->pay_checkout_id) . '</p>';
            if (PayPayments::is_pay($o) && $o->pay_transacao_id) echo '<p class="k8-muted">ID da transação PAY: ' . esc_html($o->pay_transacao_id) . '</p>';
            $consultation = PayPayments::consultation($o);
            if ($consultation) {
                echo '<details><summary>Última consulta PAY</summary><p>Consultado em: ' . esc_html($consultation['consultado_em'] ?? '') . '</p>';
                if (!empty($consultation['localizado'])) {
                    echo '<p>Estado informado pela K8: ' . esc_html($consultation['estado'] ?? '') . '</p><p>Transação consultada: ' . esc_html($consultation['transacao_id'] ?? '') . '</p>';
                    if (isset($consultation['valor'])) echo '<p>Valor da transação: ' . esc_html(self::currency((float) $consultation['valor'])) . '</p>';
                    if (isset($consultation['valor_pago'])) echo '<p>Valor pago informado pela K8: ' . esc_html(self::currency((float) $consultation['valor_pago'])) . '</p>';
                } else echo '<p>Nenhuma transação aprovada e correspondente foi localizada na busca.</p>';
                echo '<p>Situação registrada no pedido: ' . esc_html($consultation['situacao_pedido'] ?? '') . '</p></details>';
            }
            if ($o->erro_mensagem) {
                echo '<details><summary>Detalhes da tentativa</summary><p>' . esc_html($o->erro_mensagem) . '</p><p>Referência na K8: ' . esc_html(PayPayments::is_pay($o) ? PayPayments::reference($o) : (CardPayments::is_link($o) ? CardPayments::reference($o) : 'K8P-' . (int) $o->id)) . '</p></details>';
            }
            if (($o->cobranca_id || $o->link_pagamento_id || PayPayments::is_pay($o)) && $o->status_pagamento !== 'Cancelada' && (PayPayments::is_pay($o) || $o->status_pagamento !== 'Paga')) {
                $checkout_url = Service::public_order($o)['redirect'];
                if ($checkout_url) echo '<a href="' . esc_url($checkout_url) . '" target="_blank" rel="noopener">Abrir checkout K8</a>';
                self::form('sync', (int) $p->id);
                echo '<input type="hidden" name="pedido_id" value="' . (int) $o->id . '">';
                self::button('Consultar este pedido');
                echo '</form>';
            }
            if (PayPayments::is_pay($o) && !in_array($o->status_pagamento, ['Paga', 'Cancelada'], true)) {
                echo '<details><summary>Vincular transação PAY existente</summary><p>Se o pagamento já foi feito, informe o ID da transação exibido no PAY. A consulta precisa confirmar pedido, comprador, valor e forma de pagamento. Não faça outro pagamento para corrigir o retorno.</p>';
                self::form('reconcile', (int) $p->id);
                echo '<input type="hidden" name="pedido_id" value="' . (int) $o->id . '">';
                self::field('cobranca_id', 'ID da transação PAY (UUID)', '', 'text', 'required maxlength="36" autocomplete="off"');
                self::button('Conferir e vincular transação PAY');
                echo '</form></details>';
            }
            if ($o->status === 'verificacao' && !$o->cobranca_id && !$o->link_pagamento_id && !PayPayments::is_pay($o)) {
                echo '<details><summary>' . (CardPayments::is_link($o) ? 'Vincular link de cartão existente' : 'Vincular cobrança existente') . '</summary>';
                self::form('reconcile', (int) $p->id);
                echo '<input type="hidden" name="pedido_id" value="' . (int) $o->id . '">';
                self::field('cobranca_id', CardPayments::is_link($o) ? 'ID do link localizado na K8' : 'ID localizado na K8', '', 'text', 'required');
                self::button('Conferir e vincular');
                echo '</form></details>';
            }
            if ($o->status_pagamento !== 'Paga' && $o->status_pagamento !== 'Cancelada') {
                echo '<details><summary>Cancelar pedido</summary>';
                self::form('cancel', (int) $p->id);
                echo '<input type="hidden" name="pedido_id" value="' . (int) $o->id . '">';
                self::field('motivo', 'Motivo do cancelamento', '', 'text', 'required minlength="5"');
                if (PayPayments::is_pay($o)) {
                    echo '<p class="k8-muted">Encerre o checkout no painel PAY antes de liberar outra compra. Este botão não solicita estorno de pagamento.</p><label class="k8-check"><input type="checkbox" name="confirmar_sem_cobranca" value="1" required>Conferi e encerrei no PAY este checkout; não existe pagamento confirmado nem checkout ativo para esta tentativa.</label>';
                } elseif ($o->status === 'verificacao' && !$o->cobranca_id && !$o->link_pagamento_id) {
                    echo '<label class="k8-check"><input type="checkbox" name="confirmar_sem_cobranca" value="1" required>Conferi no painel K8 e não há link nem cobrança ativa para esta tentativa.</label>';
                }
                self::button('Confirmar cancelamento');
                echo '</form></details>';
            }
            echo '</td></tr>';
        }
        self::table_end();
        self::pagination($total, $page);
    }

    private static function stock(object $p): void
    {
        global $wpdb;
        $table = Support::table('materiais');
        $materials = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE produto_id = %d ORDER BY ativo DESC,nome", $p->id));
        echo '<div class="k8-grid"><section class="k8-card"><h3>Novo material</h3>';
        self::form('save_material', (int) $p->id);
        self::field('nome', 'Nome do material', '', 'text', 'required maxlength="255"');
        self::class_select($p, 'turma_restrita', 'Turma deste produto', '', true);
        echo '<label>Período de entrega<select name="periodo_entrega">';
        foreach (Support::periods() as $period => $label) {
            if ((int) $p->etapas === 1 && Support::semester($period) === 2) {
                continue;
            }
            echo '<option value="' . esc_attr($period) . '">' . esc_html($label) . '</option>';
        }
        echo '</select></label>';
        self::field('quantidade_por_aluno', 'Unidades por aluno', 1, 'number', 'min="1" max="10000" required');
        self::field('estoque_inicial', 'Estoque inicial', 0, 'number', 'min="0" max="1000000" required');
        self::field('estoque_minimo', 'Alerta de reposição até', 0, 'number', 'min="0" max="1000000" required');
        self::button('Cadastrar material');
        echo '</form></section><section class="k8-card"><h3>Movimentar estoque</h3><p class="k8-muted">' . ($p->permitir_negativo ? 'O estoque é informativo e pode ficar negativo.' : 'Saídas e entregas exigem estoque disponível.') . '</p>';
        self::form('stock', (int) $p->id);
        echo '<label>Material<select name="material_id" required>';
        foreach ($materials as $m) {
            if ($m->ativo) {
                echo '<option value="' . (int) $m->id . '">' . esc_html($m->nome) . '</option>';
            }
        }
        echo '</select></label><label>Tipo<select name="tipo"><option value="entrada">Entrada</option><option value="saida">Saída</option></select></label>';
        self::field('quantidade', 'Quantidade', 1, 'number', 'min="1" max="1000000" required');
        self::field('observacao', 'Observação', '', 'text', 'maxlength="255"');
        self::button('Registrar movimento');
        echo '</form></section></div>';
        self::table_start(['Material', 'Turma', 'Período', 'Unidades/aluno', 'Saldo', 'Situação']);
        foreach ($materials as $m) {
            echo '<tr><td>' . esc_html($m->nome) . '</td><td>' . esc_html($m->turma_restrita ?: 'Turmas deste produto') . '</td><td>' . esc_html(Support::periods()[$m->periodo_entrega] ?? $m->periodo_entrega) . '</td><td>' . (int) $m->quantidade_por_aluno . '</td><td class="' . ($m->estoque_atual <= $m->estoque_minimo ? 'k8-error' : '') . '">' . (int) $m->estoque_atual . '</td><td>';
            self::form('toggle_material', (int) $p->id);
            echo '<input type="hidden" name="id" value="' . (int) $m->id . '">';
            self::button($m->ativo ? 'Desativar' : 'Ativar');
            echo '</form></td></tr>';
        }
        self::table_end();
    }

    private static function deliveries(object $p): void
    {
        global $wpdb;
        $filter = self::filters((int) $p->id, 'deliveries', true);
        $stage = max(1, min((int) $p->etapas, absint($_GET['k8_stage'] ?? 1)));
        echo '<div class="k8-tabs">';
        for ($i = 1; $i <= (int) $p->etapas; $i++) {
            echo '<a href="' . esc_url(add_query_arg(['k8_stage' => $i, 'k8_page' => 1])) . '" ' . ($stage === $i ? 'aria-current="page"' : '') . '>' . ((int) $p->etapas === 1 ? 'Entrega única' : $i . 'º semestre') . '</a>';
        }
        echo '</div>';
        $orders = Support::table('pedidos');
        $deliveries = Support::table('entregas');
        $where = self::where((int) $p->id, $filter) . " AND (p.status_pagamento = 'Paga' OR e.status = 'entregue')";
        if (in_array($filter['state'], ['entregue', 'pendente'], true)) {
            $where .= $wpdb->prepare(" AND COALESCE(e.status,'pendente') = %s", $filter['state']);
        }
        $join = $wpdb->prepare("FROM $orders p LEFT JOIN $deliveries e ON e.pedido_id = p.id AND e.produto_id = p.produto_id AND e.semestre = %d WHERE $where", $stage);
        $page = max(1, absint($_GET['k8_page'] ?? 1));
        $total = (int) $wpdb->get_var("SELECT COUNT(*) $join");
        $rows = $wpdb->get_results($wpdb->prepare("SELECT p.*,e.id AS entrega_id,e.status AS entrega_status,e.assinatura AS entrega_assinatura,e.materiais_entregues AS delivery_items,e.entregue_em AS data_entrega,e.recebido_por $join ORDER BY p.criado_em ASC,p.id ASC LIMIT 50 OFFSET %d", ($page - 1) * 50));
        self::table_start(['Aluno / pedido', 'Materiais desta entrega', 'Situação', 'Registrar']);
        foreach ($rows as $o) {
            echo '<tr><td><strong>' . esc_html($o->nome_aluno) . '</strong><br>' . esc_html($o->turma) . ' · RA ' . esc_html($o->ra) . '<br>Pedido #' . (int) $o->id . ($o->status_pagamento !== 'Paga' ? '<br>Pagamento: ' . esc_html($o->status_pagamento) : '') . '</td><td><ul>';
            if ($o->entrega_status === 'entregue') {
                foreach ((json_decode((string) $o->delivery_items, true) ?: []) as $m) {
                    echo '<li>' . (int) ($m['quantidade'] ?? 1) . ' × ' . esc_html($m['nome'] ?? '#' . $m['id']) . '</li>';
                }
            } else {
                foreach (Service::materials((int) $p->id, $o->turma, $stage) as $m) {
                    echo '<li>' . (int) $m->quantidade_por_aluno . ' × ' . esc_html($m->nome) . '</li>';
                }
            }
            echo '</ul></td><td>' . esc_html($o->entrega_status ?: 'pendente');
            if ($o->entrega_status === 'entregue') {
                echo '<br><small>' . esc_html($o->data_entrega) . '<br>' . esc_html($o->recebido_por ?: '') . '</small>';
                if (strpos((string) $o->entrega_assinatura, 'data:image/png;base64,') === 0) {
                    echo '<details><summary>Assinatura</summary><img class="k8-sign-preview" alt="Assinatura do recebimento" src="' . esc_attr($o->entrega_assinatura) . '"></details>';
                }
            }
            echo '</td><td>';
            self::form('delivery', (int) $p->id);
            echo '<input type="hidden" name="pedido_id" value="' . (int) $o->id . '"><input type="hidden" name="semestre" value="' . $stage . '">';
            if ($o->entrega_status === 'entregue') {
                echo '<input type="hidden" name="acao" value="desfazer">';
                self::field('motivo', 'Justificativa do estorno', '', 'text', 'required minlength="5"');
                self::button('Desfazer entrega');
            } else {
                echo '<input type="hidden" name="acao" value="entregar"><input type="hidden" name="assinatura"><button type="button" class="k8-btn" data-k8-sign data-student="' . esc_attr($o->nome_aluno) . '">Confirmar entrega e assinar</button>';
            }
            echo '</form></td></tr>';
        }
        self::table_end();
        self::pagination($total, $page);
        ?>
        <dialog class="k8-sign-dialog"><form class="k8-form" data-k8-sign-form><h3>Confirmar recebimento</h3><p data-k8-sign-name></p><label>Nome de quem está recebendo<input name="recebido_por" required maxlength="255"></label><p class="k8-muted">Confira os materiais da linha antes de confirmar. Assine abaixo:</p><canvas width="600" height="220" aria-label="Área de assinatura"></canvas><div class="k8-inline"><button type="button" class="k8-btn secondary" data-k8-clear>Limpar</button><button type="button" class="k8-btn secondary" data-k8-close>Voltar</button><button type="submit" class="k8-btn">Registrar entrega</button></div><p data-k8-sign-error class="k8-error" role="alert"></p></form></dialog>
        <?php
    }

    private static function coupons(object $p): void
    {
        global $wpdb;
        echo '<section class="k8-card"><h3>Criar ou atualizar cupom</h3><p class="k8-muted">Reutilize o código para atualizar as regras. O histórico de usos será mantido.</p>';
        self::form('save_coupon', (int) $p->id, 'k8-form-grid');
        self::field('codigo', 'Código', '', 'text', 'required maxlength="50" pattern="[A-Za-z0-9_-]+"');
        self::field('percentual', 'Desconto (%)', '', 'number', 'required min="0.01" max="100" step="0.01"');
        self::class_select($p, 'turma_restrita', 'Turma deste produto', '', true);
        self::field('validade', 'Validade', '', 'date');
        self::field('uso_maximo', 'Limite de usos (vazio = ilimitado)', '', 'number', 'min="1"');
        self::button('Salvar cupom');
        echo '</form></section>';
        $table = Support::table('cupons');
        self::table_start(['Código', 'Desconto', 'Turma', 'Validade', 'Usos', 'Situação']);
        foreach ($wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE produto_id = %d ORDER BY id DESC", $p->id)) as $c) {
            echo '<tr><td>' . esc_html($c->codigo) . '</td><td>' . esc_html($c->percentual) . '%</td><td>' . esc_html($c->turma_restrita ?: 'Turmas deste produto') . '</td><td>' . esc_html($c->validade ?: 'Sem prazo') . '</td><td>' . (int) $c->usado_count . ' / ' . esc_html($c->uso_maximo ?? '∞') . '</td><td>';
            self::form('toggle_coupon', (int) $p->id);
            echo '<input type="hidden" name="id" value="' . (int) $c->id . '">';
            self::button($c->ativo ? 'Desativar' : 'Ativar');
            echo '</form></td></tr>';
        }
        self::table_end();
    }

    private static function history(object $p): void
    {
        global $wpdb;
        $table = Support::table('estoque_movimentos');
        $materials = Support::table('materiais');
        $page = max(1, absint($_GET['k8_page'] ?? 1));
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE produto_id = %d", $p->id));
        echo '<h3>Movimentações de estoque</h3>';
        self::table_start(['Data', 'Material', 'Movimento', 'Observação', 'Operador']);
        foreach ($wpdb->get_results($wpdb->prepare("SELECT s.*,m.nome FROM $table s LEFT JOIN $materials m ON m.id = s.material_id AND m.produto_id = s.produto_id WHERE s.produto_id = %d ORDER BY s.id DESC LIMIT 50 OFFSET %d", $p->id, ($page - 1) * 50)) as $row) {
            echo '<tr><td>' . esc_html($row->criado_em) . '</td><td>' . esc_html($row->nome ?: '#' . $row->material_id) . '</td><td>' . esc_html($row->tipo) . ' · ' . (int) $row->quantidade . '</td><td>' . esc_html($row->observacao) . '</td><td>' . esc_html($row->usuario) . '</td></tr>';
        }
        self::table_end();
        self::pagination($total, $page);
        echo '<h3>Entregas, estornos e cancelamentos recentes</h3>';
        $table = Support::table('entregas_log');
        self::table_start(['Data', 'Pedido', 'Ação', 'Operador', 'Detalhes']);
        foreach ($wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE produto_id = %d ORDER BY id DESC LIMIT 100", $p->id)) as $row) {
            echo '<tr><td>' . esc_html($row->criado_em) . '</td><td>#' . (int) $row->pedido_id . '</td><td>' . esc_html($row->acao) . '</td><td>' . esc_html($row->usuario) . '</td><td>' . esc_html($row->motivo ?: '—');
            $details = json_decode((string) $row->dados, true) ?: [];
            if (!empty($details['semestre'])) {
                echo '<br>Etapa ' . (int) $details['semestre'];
            }
            foreach (($details['materiais'] ?? []) as $m) {
                echo '<br>' . (int) ($m['quantidade'] ?? 1) . ' × ' . esc_html($m['nome'] ?? '#' . $m['id']);
            }
            if (strpos((string) $row->assinatura, 'data:image/png;base64,') === 0) {
                echo '<details><summary>Assinatura</summary><img class="k8-sign-preview" alt="Assinatura registrada" src="' . esc_attr($row->assinatura) . '"></details>';
            }
            echo '</td></tr>';
        }
        self::table_end();
    }

    public static function admin_products(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        global $wpdb;
        self::shell();
        wp_enqueue_media();
        echo '<h1>Produtos e preços</h1><div class="k8-grid k8-product-editor-grid"><section class="k8-card"><h2>Produtos cadastrados</h2><a href="' . esc_url(admin_url('admin.php?page=k8prod-products')) . '">+ Novo produto</a><ul class="k8-product-list">';
        foreach (Support::products() as $product) {
            echo '<li><a href="' . esc_url(admin_url('admin.php?page=k8prod-products&produto_id=' . $product->id)) . '">' . esc_html($product->nome) . '</a> ' . ($product->ativo ? '' : '<span class="k8-muted">Inativo</span>') . '<br><code>[k8_produto id="' . (int) $product->id . '"]</code>';
            self::form('set_product_status', (int) $product->id, 'k8-visibility-action');
            echo '<input type="hidden" name="ativo" value="' . ($product->ativo ? '0' : '1') . '">';
            self::button($product->ativo ? 'Desativar produto' : 'Reativar produto');
            echo '</form></li>';
        }
        echo '</ul></section><div class="k8-product-editor"><section class="k8-card">';
        $id = absint($_GET['produto_id'] ?? 0);
        $p = (object) ['nome' => '', 'descricao' => '', 'valor_padrao' => null, 'etapas' => 1, 'permitir_negativo' => 0, 'vencimento_dias' => 5, 'ativo' => 1,
            'categoria' => 'didatico', 'imagem_id' => 0, 'publicado' => 1, 'ordem' => 0, 'turmas_disponiveis' => '[]',
            'formas_pagamento' => wp_json_encode(array_keys(PaymentTerms::labels())), 'cartao_parcelas' => 1];
        if ($id) {
            try {
                $p = Support::product($id);
            } catch (\Throwable $e) {
                echo '<p>' . esc_html($e->getMessage()) . '</p></section></div></div></div>';
                return;
            }
        }
        echo '<h2>' . ($id ? 'Editar produto: ' . esc_html($p->nome) : 'Criar produto') . '</h2>';
        self::form('save_product', $id);
        echo '<label>Situação do produto<select name="ativo" data-k8-product-status><option value="1" ' . selected($p->ativo, 1, false) . '>Ativo no site</option><option value="0" ' . selected($p->ativo, 0, false) . '>Desativado — ocultar totalmente do site</option></select></label><p class="k8-muted">Ao desativar, o produto sai da home, dos catálogos e dos shortcodes. O link direto passa a retornar página não encontrada. Pedidos, estoque e entregas continuam disponíveis no painel.</p>';
        self::field('nome', 'Nome', $p->nome, 'text', 'required maxlength="255"');
        echo '<label>Descrição<textarea name="descricao" rows="3">' . esc_textarea($p->descricao) . '</textarea></label>';
        echo '<label>Categoria<select name="categoria">';
        foreach (Storefront::categories() as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($p->categoria, $key, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label><input type="hidden" name="imagem_id" value="' . (int) $p->imagem_id . '"><div data-k8-image-preview>';
        if ($p->imagem_id) {
            echo wp_get_attachment_image((int) $p->imagem_id, 'thumbnail');
        }
        echo '</div><div class="k8-inline"><button class="k8-btn secondary" type="button" data-k8-image>Escolher imagem</button><button class="k8-btn secondary" type="button" data-k8-image-remove>Remover imagem</button></div>';
        self::field('ordem', 'Ordem de exibição no catálogo', $p->ordem, 'number');
        echo '<label class="k8-check"><input type="checkbox" name="publicado" value="1" ' . checked($p->publicado, 1, false) . '>Exibir este produto na home e no catálogo</label>';
        self::classes_form($p);
        self::field('valor_padrao', 'Preço normal deste produto (R$)', $p->valor_padrao ?? '', 'text', 'inputmode="decimal" ' . ($p->ativo ? 'required' : ''));
        echo '<p class="k8-muted">Este é o preço normal do produto para as turmas selecionadas. Configure as promoções em Preço por data abaixo.</p>';
        self::payment_settings($p);
        echo '<label>Modelo de entrega<select name="etapas"><option value="1" ' . selected($p->etapas, 1, false) . '>Entrega única</option><option value="2" ' . selected($p->etapas, 2, false) . '>Duas etapas / semestres</option></select></label>';
        self::field('vencimento_dias', 'Dias para vencimento da cobrança', $p->vencimento_dias, 'number', 'min="1" max="365" required');
        echo '<label class="k8-check"><input type="checkbox" name="permitir_negativo" value="1" ' . checked($p->permitir_negativo, 1, false) . '>Permitir saídas com estoque negativo</label>';
        self::button('Salvar produto');
        echo '</form></section>';
        if ($id) {
            self::discounts_form($id);
            self::payment_periods_form($id);
            self::emails_form($p);
            echo '<section class="k8-card"><h2>Publicar e administrar este produto</h2><p><a target="_blank" rel="noopener" href="' . esc_url(Storefront::url($id)) . '">Abrir página de compra deste produto ↗</a></p><p>Fluxo de compra: <code>[k8_produto id="' . $id . '"]</code></p><p>Painel iniciando neste produto: <code>[k8_dashboard produto="' . $id . '"]</code></p></section>';
        } else {
            echo '<section class="k8-card"><h2>Preço e parcelamento por data deste produto</h2><p>Salve o produto com suas turmas e formas de pagamento para cadastrar os preços promocionais e os períodos de parcelamento nesta mesma tela.</p></section>';
        }
        echo '</div></div></div>';
    }


    private static function emails_form(object $product): void
    {
        global $wpdb;
        $id = (int) $product->id;
        $config = Emails::settings($product);
        echo '<section class="k8-card" id="emails-produto"><h2>E-mails deste produto</h2><p>Os envios usam o <strong>SMTP já configurado no WordPress</strong>. Ative cada tipo somente nos produtos em que deseja utilizá-lo. As opções começam desligadas; pedidos antigos não entram em disparos retroativos.</p>';
        self::form('save_email_settings', $id);
        echo '<label class="k8-check"><input type="checkbox" name="mail_confirmacao" value="1" ' . checked((int) $config['confirmacao'], 1, false) . '>Enviar confirmação após o pagamento confirmado</label>';
        echo '<p class="k8-muted">Inclui cortesia. Ao ativar, o comprador precisa informar o e-mail antes de concluir um novo pedido. Pedido apenas gerado ou em conferência ainda não recebe confirmação.</p>';
        echo '<label class="k8-check"><input type="checkbox" name="mail_carrinho" value="1" ' . checked((int) $config['carrinho'], 1, false) . '>Enviar lembrete de carrinho abandonado</label>';
        self::field('mail_espera', 'Minutos sem atividade antes do lembrete', $config['espera'], 'number', 'min="15" max="10080" required');
        echo '<p class="k8-muted">Um lembrete por aluno, responsável e produto, somente quando o comprador informar um e-mail válido e escolher receber lembrete. Vale para compras interrompidas antes do pedido e para pagamentos pendentes. Pagos, cancelados, produtos desativados e preferências canceladas são conferidos antes de enviar. Carrinhos expiram após 30 dias sem atividade.</p>';
        foreach (['confirmacao' => 'Confirmação de compra', 'carrinho' => 'Carrinho abandonado'] as $type => $label) {
            echo '<h3>' . esc_html($label) . '</h3>';
            self::field('mail_assunto_' . $type, 'Assunto', $config['assunto_' . $type], 'text', 'required maxlength="200"');
            echo '<p>Texto da mensagem</p>';
            wp_editor($config['texto_' . $type], 'k8_mail_' . $type, [
                'textarea_name' => 'mail_texto_' . $type, 'textarea_rows' => 8, 'media_buttons' => false, 'teeny' => true,
            ]);
        }
        echo '<details><summary>Marcadores de personalização disponíveis</summary><p>Copie o marcador com os colchetes para o assunto ou texto. Os links também podem ser usados como endereço de um botão ou link no editor. São substituições do e-mail; outros shortcodes do WordPress não são executados.</p>';
        self::table_start(['Marcador', 'Conteúdo']);
        foreach (Emails::markers() as $key => $label) echo '<tr><td><code>[' . esc_html($key) . ']</code></td><td>' . esc_html($label) . '</td></tr>';
        self::table_end();
        echo '</details><p class="k8-muted">O lembrete inclui um link para cancelar novos lembretes, mesmo que o texto seja personalizado. O preço de um carrinho sem pedido é recalculado; pedidos emitidos mantêm o valor registrado.</p>';
        self::button('Salvar e-mails deste produto');
        echo '</form><h3>Histórico de envios deste produto</h3>';
        $worker = get_option('k8prod_mail_worker_state');
        if (is_array($worker) && !empty($worker['data'])) {
            echo '<p class="k8-muted">Última execução da fila do site: ' . esc_html(get_date_from_gmt($worker['data'], 'd/m/Y H:i')) . (!empty($worker['erro']) ? ' · ' . esc_html($worker['erro']) : '') . '.</p>';
        }
        echo '<p class="k8-muted">A fila é verificada a cada cinco minutos pelo WP-Cron; o horário depende da execução do agendador do site. “Enviado” significa aceito pelo WordPress/SMTP. Consulte os registros do SMTP para confirmar a entrega na caixa de entrada.</p>';
        $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . Support::table('emails') . ' WHERE produto_id = %d ORDER BY id DESC LIMIT 30', $id));
        $labels = ['fila' => 'Na fila', 'enviando' => 'Enviando', 'enviado' => 'Enviado', 'falha' => 'Falha após três tentativas', 'conferir' => 'Conferir no SMTP', 'cancelado' => 'Cancelado'];
        self::table_start(['Tipo', 'Destinatário', 'Pedido', 'Situação', 'Tentativas', 'Data', 'Ações']);
        foreach ($rows as $row) {
            echo '<tr><td>' . ($row->tipo === 'confirmacao' ? 'Confirmação' : 'Carrinho') . '</td><td>' . esc_html($row->email) . '</td><td>' . ($row->pedido_id ? '#' . (int) $row->pedido_id : 'Sem pedido') . '</td><td>' . esc_html($labels[$row->estado] ?? $row->estado);
            if ($row->erro) echo '<br><span class="k8-muted">' . esc_html($row->erro) . '</span>';
            echo '</td><td>' . (int) $row->tentativas . '</td><td>' . esc_html(get_date_from_gmt($row->enviado_em ?: $row->criado_em, 'd/m/Y H:i')) . '</td><td>';
            if (in_array($row->estado, ['falha', 'conferir'], true)) {
                self::form('retry_email', $id, '', 'Confira o log do SMTP antes de repetir: um envio interrompido pode já ter sido aceito. Deseja colocar este e-mail na fila novamente?');
                echo '<input type="hidden" name="id" value="' . (int) $row->id . '">';
                self::button('Tentar novamente');
                echo '</form>';
            }
            echo '</td></tr>';
        }
        self::table_end();
        echo '</section>';
    }

    private static function classes_form(object $product): void
    {
        $selected = ProductClasses::selected($product);
        echo '<fieldset class="k8-product-classes"><legend>Turmas disponíveis para este produto</legend><p>Marque as turmas que podem comprar este produto.</p><div class="k8-class-options">';
        foreach (ProductClasses::options($product) as $class) {
            echo '<label class="k8-check"><input type="checkbox" name="turmas[]" value="' . esc_attr($class) . '" ' . checked(in_array($class, $selected, true), true, false) . '>' . esc_html($class) . '</label>';
        }
        echo '</div><label>Outras turmas deste produto (uma por linha)<textarea name="turmas_adicionais" rows="2" placeholder="Ex.: 5º Ano A"></textarea></label><p class="k8-muted">Use este campo se a turma ainda não estiver na lista. Cada turma informada será selecionada neste produto. Turmas novas importadas depois precisam ser selecionadas nos produtos em que poderão comprar.</p></fieldset>';
    }

    private static function installments_select(string $name, string $label, int $selected): void
    {
        echo '<label>' . esc_html($label) . '<select name="' . esc_attr($name) . '" required>';
        for ($n = 1; $n <= 12; $n++) {
            echo '<option value="' . $n . '" ' . selected($n, $selected, false) . '>' . ($n === 1 ? '1x — à vista' : 'Até ' . $n . 'x no cartão') . '</option>';
        }
        echo '</select></label>';
    }

    private static function payment_settings(object $product): void
    {
        $methods = PaymentTerms::methods($product);
        echo '<fieldset class="k8-product-classes"><legend>Formas de pagamento deste produto</legend><p>Marque as opções que o comprador poderá usar.</p><div class="k8-class-options">';
        foreach (PaymentTerms::labels() as $key => $label) {
            echo '<label class="k8-check"><input type="checkbox" name="formas_pagamento[]" value="' . esc_attr($key) . '" ' . checked(in_array($key, $methods, true), true, false) . '>' . esc_html($label) . '</label>';
        }
        echo '</div>';
        self::installments_select('cartao_parcelas', 'Parcelamento no cartão fora dos períodos especiais', (int) ($product->cartao_parcelas ?? 1));
        echo '<p class="k8-muted">Este é o máximo de parcelas quando não houver uma faixa por data em vigor. Só se aplica quando o cartão está habilitado. Pix e boleto são pagos à vista; a quantidade efetiva de parcelas é escolhida no checkout da K8 dentro do limite.</p></fieldset>';
    }

    private static function payment_periods_form(int $product): void
    {
        global $wpdb;
        $p = Support::product($product);
        $table = Support::table('parcelamento_data');
        $edit = absint($_GET['k8_installment'] ?? 0);
        $rule = $edit ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d AND produto_id = %d", $edit, $product)) : null;
        $rule = $rule ?: (object) ['id' => 0, 'titulo' => '', 'inicio' => '', 'fim' => '', 'parcelas' => 1];
        echo '<section class="k8-card" id="parcelamento-data"><h2>Parcelamento por data deste produto</h2><p><strong>' . esc_html($p->nome) . '</strong> · Defina o máximo de parcelas no cartão em cada período. Exemplo: até 10x até uma data e até 6x depois, usando 6x como limite fora das faixas.</p><p class="k8-muted">A data final inclui o dia inteiro no fuso ' . esc_html(wp_timezone_string()) . '. Períodos ativos não podem se sobrepor. Preço e parcelamento têm calendários próprios. Pedidos já emitidos mantêm as condições registradas.</p>';
        if (!in_array('Cartao', PaymentTerms::methods($p), true)) echo '<p class="k8-notice">O cartão está desabilitado neste produto. As faixas terão efeito quando você habilitar essa forma de pagamento no cadastro acima.</p>';
        self::form('save_payment_period', $product, 'k8-form-grid');
        echo '<input type="hidden" name="id" value="' . (int) $rule->id . '">';
        self::field('titulo', 'Nome do período', $rule->titulo, 'text', 'required maxlength="160" placeholder="Ex.: Compra antecipada"');
        self::installments_select('parcelas', 'Máximo de parcelas no cartão', (int) $rule->parcelas);
        self::field('inicio', 'Início (vazio = imediato)', $rule->inicio, 'date');
        self::field('fim', 'Válido até (inclusive)', $rule->fim, 'date', 'required');
        self::button($rule->id ? 'Atualizar parcelamento' : 'Cadastrar parcelamento');
        echo '</form>';
        if ($rule->id) echo '<p><a href="' . esc_url(admin_url('admin.php?page=k8prod-products&produto_id=' . $product . '#parcelamento-data')) . '">Cadastrar outro período</a></p>';
        self::table_start(['Nome', 'Parcelas no cartão', 'Período', 'Situação', 'Ações']);
        $today = Discounts::today();
        foreach ($wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE produto_id = %d ORDER BY fim,id", $product)) as $row) {
            $status = !$row->ativo ? 'Inativo' : ($row->fim < $today ? 'Encerrado' : ($row->inicio && $row->inicio > $today ? 'Agendado' : 'Em vigor'));
            echo '<tr><td>' . esc_html($row->titulo) . '</td><td>Até ' . (int) $row->parcelas . 'x</td><td>' . esc_html(($row->inicio ? Discounts::date_label($row->inicio) : 'Imediato') . ' até ' . Discounts::date_label($row->fim)) . '</td><td>' . esc_html($status) . '</td><td><a href="' . esc_url(add_query_arg(['page' => 'k8prod-products', 'produto_id' => $product, 'k8_installment' => $row->id], admin_url('admin.php')) . '#parcelamento-data') . '">Editar</a>';
            self::form('toggle_payment_period', $product);
            echo '<input type="hidden" name="id" value="' . (int) $row->id . '">';
            self::button($row->ativo ? 'Desativar' : 'Ativar');
            echo '</form>';
            self::form('delete_payment_period', $product, '', 'Excluir esta faixa de parcelamento? Os pedidos já emitidos manterão suas condições.');
            echo '<input type="hidden" name="id" value="' . (int) $row->id . '">';
            self::button('Excluir faixa');
            echo '</form></td></tr>';
        }
        self::table_end();
        echo '</section>';
    }

    private static function class_select(object $product, string $name, string $label, string $value = '', bool $optional = false): void
    {
        $classes = ProductClasses::selected($product);
        echo '<label>' . esc_html($label) . '<select name="' . esc_attr($name) . '" ' . ($optional ? '' : 'required') . '>';
        echo '<option value="">' . ($optional ? 'Turmas selecionadas neste produto' : 'Selecione uma turma') . '</option>';
        if ($value !== '' && !in_array($value, $classes, true)) {
            echo '<option value="' . esc_attr($value) . '" selected>' . esc_html($value . ' (turma não selecionada no produto)') . '</option>';
        }
        foreach ($classes as $class) {
            echo '<option value="' . esc_attr($class) . '" ' . selected($class, $value, false) . '>' . esc_html($class) . '</option>';
        }
        echo '</select></label>';
    }

    private static function discounts_form(int $product): void
    {
        global $wpdb;
        $p = Support::product($product);
        $table = Support::table('descontos_data');
        $edit = absint($_GET['k8_discount'] ?? 0);
        $rule = $edit ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d AND produto_id = %d", $edit, $product)) : null;
        $rule = $rule ?: (object) ['id' => 0, 'titulo' => '', 'tipo' => 'percentual', 'valor' => '', 'turma_restrita' => '', 'inicio' => '', 'fim' => '', 'acumular_cupom' => 0];
        echo '<section class="k8-card" id="descontos-data"><h2>Preço por data deste produto</h2><p><strong>' . esc_html($p->nome) . '</strong> · Cadastre o preço promocional ou percentual e o período. A regra vale somente para este produto e suas turmas selecionadas.</p><p class="k8-muted">O catálogo e a compra mostram o valor normal, o valor menor e a data limite. A data final inclui o dia inteiro. Fuso do site: ' . esc_html(wp_timezone_string()) . '. Faixas sobrepostas usam o menor preço. Pedidos já gerados mantêm seu valor.</p>';
        self::form('save_discount', $product, 'k8-form-grid');
        echo '<input type="hidden" name="id" value="' . (int) $rule->id . '">';
        self::field('titulo', 'Nome do desconto', $rule->titulo, 'text', 'required maxlength="160" placeholder="Ex.: Compra antecipada"');
        echo '<label>Tipo<select name="tipo"><option value="percentual" ' . selected($rule->tipo, 'percentual', false) . '>Desconto percentual (%)</option><option value="preco" ' . selected($rule->tipo, 'preco', false) . '>Preço promocional (R$)</option></select></label>';
        self::field('valor', 'Percentual ou preço final', $rule->valor, 'text', 'required inputmode="decimal" placeholder="Ex.: 10 ou 890,00"');
        self::class_select($p, 'turma_restrita', 'Aplicar o preço por data às turmas', (string) $rule->turma_restrita, true);
        self::field('inicio', 'Início (vazio = imediato)', $rule->inicio, 'date');
        self::field('fim', 'Válido até (inclusive)', $rule->fim, 'date', 'required');
        echo '<label class="k8-check"><input type="checkbox" name="acumular_cupom" value="1" ' . checked($rule->acumular_cupom, 1, false) . '>Permitir acumular com cupom</label>';
        self::button($rule->id ? 'Atualizar desconto' : 'Cadastrar desconto');
        echo '</form><p class="k8-muted">Sem acumulação, vale o melhor preço entre a promoção e o cupom; um cupom que não melhorar o valor não será consumido.</p>';
        if ($rule->id) {
            echo '<a href="' . esc_url(admin_url('admin.php?page=k8prod-products&produto_id=' . $product . '#descontos-data')) . '">Cadastrar outro desconto</a>';
        }
        self::table_start(['Nome / turma', 'Desconto', 'Período', 'Situação', 'Ações']);
        $today = Discounts::today();
        foreach ($wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE produto_id = %d ORDER BY fim ASC,id ASC", $product)) as $row) {
            $status = !$row->ativo ? 'Inativo' : ($row->fim < $today ? 'Encerrado' : ($row->inicio && $row->inicio > $today ? 'Agendado' : 'Em vigor'));
            echo '<tr><td><strong>' . esc_html($row->titulo) . '</strong><br>' . esc_html($row->turma_restrita ?: 'Turmas selecionadas neste produto') . '</td><td>' .
                esc_html($row->tipo === 'percentual' ? number_format((float) $row->valor, 2, ',', '.') . '%' : self::currency($row->valor)) . '<br><small>' .
                ($row->acumular_cupom ? 'Acumula com cupom' : 'Não acumula') . '</small></td><td>' .
                esc_html(($row->inicio ? Discounts::date_label($row->inicio) : 'Imediato') . ' até ' . Discounts::date_label($row->fim)) . '</td><td>' . esc_html($status) . '</td><td>';
            echo '<a href="' . esc_url(add_query_arg(['page' => 'k8prod-products', 'produto_id' => $product, 'k8_discount' => $row->id], admin_url('admin.php')) . '#descontos-data') . '">Editar</a>';
            self::form('toggle_discount', $product);
            echo '<input type="hidden" name="id" value="' . (int) $row->id . '">';
            self::button($row->ativo ? 'Desativar' : 'Ativar');
            echo '</form>';
            self::form('delete_discount', $product, '', 'Excluir esta faixa de preço? Os pedidos já emitidos manterão seus valores.');
            echo '<input type="hidden" name="id" value="' . (int) $row->id . '">';
            self::button('Excluir faixa');
            echo '</form></td></tr>';
        }
        self::table_end();
        echo '</section>';
    }

    public static function admin_settings(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        self::shell();
        echo '<h1>Configurações K8</h1>';
        self::form('settings', 0);
        echo '<section class="k8-card"><h2>Novas compras</h2><label>Provedor de pagamento<select name="gateway"><option value="cob" ' . selected(PayPayments::gateway(), 'cob', false) . '>K8 COB</option><option value="pay" ' . selected(PayPayments::gateway(), 'pay', false) . '>K8 PAY — checkout hospedado v2</option></select></label><p>Cartão, Pix e boleto novos usam o provedor escolhido. Cada pedido anterior continua no seu provedor de origem.</p><label class="k8-check"><input type="checkbox" name="producao" value="1" ' . checked(get_option('k8p_producao', '0'), '1', false) . '>Usar ambiente de produção</label></section>';
        foreach (['production' => 'PAY — produção', 'sandbox' => 'PAY — testes (sandbox)'] as $environment => $title) {
            echo '<section class="k8-card"><h2>' . esc_html($title) . '</h2><p>' . (PayClient::configured($environment) ? 'Credenciais cadastradas.' : 'Credenciais ainda não cadastradas.') . ' Deixe os campos vazios para manter os valores existentes.</p>';
            $prefix = 'pay_' . ($environment === 'sandbox' ? 'sandbox_' : '');
            self::field($prefix . 'client_id', 'Client ID do PAY', '', 'text', 'autocomplete="off"');
            self::field($prefix . 'client_secret', 'Client Secret do PAY', '', 'password', 'autocomplete="new-password"');
            self::field($prefix . 'aes_key', 'Chave AES do PAY', '', 'password', 'autocomplete="new-password"');
            echo '</section>';
        }
        echo '<details class="k8-card"><summary>Credenciais COB e pedidos anteriores</summary><p>Mantenha as credenciais COB para consultar pagamentos e pedidos antigos. Deixe os campos vazios para mantê-las.</p>';
        self::field('client_id', 'Client ID', '', 'text', 'autocomplete="off"');
        self::field('client_secret', 'Client Secret', '', 'password', 'autocomplete="new-password"');
        self::field('aes_key', 'Chave AES', '', 'password', 'autocomplete="new-password"');
        echo '</details><section class="k8-card"><h2>Base de alunos</h2><p>O nome da tabela recebe o prefixo do WordPress automaticamente. As colunas do segundo responsável são opcionais.</p>';
        $labels = ['table' => 'Tabela (sem prefixo)', 'ra' => 'Coluna RA', 'name' => 'Nome do aluno', 'class' => 'Turma',
            'cpf1' => 'CPF do responsável 1', 'parent1' => 'Nome do responsável 1', 'cpf2' => 'CPF do responsável 2', 'parent2' => 'Nome do responsável 2'];
        foreach (Students::config() as $key => $value) {
            self::field('student_' . $key, $labels[$key], $value);
        }
        echo '</section><details class="k8-card"><summary>Endpoints K8 e URLs de checkout</summary><p>Endereços próprios de cada serviço e ambiente. Altere somente quando a K8 fornecer outros endereços para sua conta.</p>';
        $defaults = ['api_production' => 'https://pagamentos.meuk8.com.br/CobrancasAPI', 'api_sandbox' => 'https://sandbox.meuk8.com.br/CobrancasAPI',
            'checkout_production' => 'https://pagamentos.k8bank.com.br/cobrancasui/checkout', 'checkout_sandbox' => 'https://pagamentos.k8bank.com.br/cobrancasui/checkout',
            'pay_api_production' => 'https://pagamentos.meuk8.com.br/PagamentosAPI', 'pay_api_sandbox' => 'https://sandbox.meuk8.com.br/PagamentosAPI',
            'query_path' => '/api/Cobranca/{id}', 'cancel_path' => '/api/Cobranca/{id}'];
        foreach ($defaults as $key => $value) {
            self::field($key, $key, get_option('k8prod_' . $key, $value), strpos($key, 'path') !== false ? 'text' : 'url', 'required');
        }
        echo '</details>';
        self::button('Salvar configurações');
        echo '</form>';
        self::form('pay_check', 0);
        self::button('Verificar conexão PAY');
        echo '<p class="k8-muted">Salve as credenciais antes de verificar. A consulta lê a configuração do ambiente selecionado e não cria pagamentos.</p></form>';
        Updates::status();
        echo '</div>';
    }
}
